from IPython.display import display, Markdown as md

def Markdown(text="hello"):
    display(md(text))
