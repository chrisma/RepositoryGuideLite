from django.test import TestCase

# python manage.py test apps.ws -v 2


class WsTestCase(TestCase):
    def test_ws(self):
        pass
